<?php 	
	include "login/login_routes.php";
	// include "registration/registration_route.php";
	include "dashboard/dashboard_route.php";
	include "user/user_route.php";
	include "tree/tree_route.php";
	include "level/level_route.php";
	include "activation/activation_route.php";
	include "videos/videos_route.php";
	include "withdrawal/withdrawal_route.php";
	include "notification/notification_route.php";
	include "profile/profile_route.php";
	// include "myaccount/myaccount_route.php";
	// include "mlm/mlm_route.php";
	
?>