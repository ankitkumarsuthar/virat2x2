<?php 	
	include "login/login_route.php";
	include "registration/registration_route.php";
	include "dashboard/dashboard_route.php";
	include "myaccount/myaccount_route.php";
	include "mlm/mlm_route.php";
	include "work/work_route.php";
	include "wallet/wallet_route.php";
	include "tree/tree_route.php";
	
?>