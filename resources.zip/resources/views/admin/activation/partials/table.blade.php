<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                       
                <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>User Id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Sponser</th>
                            <th>Mobile</th>
                            <th>Action</th> 
                        </tr>
                    </thead>                    
                </table>
                
            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div><!-- end col-->
</div>