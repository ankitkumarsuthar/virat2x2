<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                       
                <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>User Id</th>
                            <th>Name</th>
                            <th>Details</th>
                            <th>Amount</th>
                            <th>Payment Option</th>
                            <th>Payment Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>                    
                </table>
                
            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div><!-- end col-->
</div>