<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">              

                <table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Detail</th>
                            <th>Amount</th>
                            <th>Option</th>
                            <th>Status</th>                            
                        </tr>
                    </thead>                
                </table>
                
            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div><!-- end col-->
</div>